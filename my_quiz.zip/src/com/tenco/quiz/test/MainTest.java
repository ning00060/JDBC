package com.tenco.quiz.test;

import java.util.List;

public class MainTest {

	public static void main(String[] args) {
		QuizRepositoryImpl quizRepositoryImpl = new QuizRepositoryImpl();
//		try {
//			String question="1+1은";
//			String answer="2";
//			int addQuiz=quizRepositoryImpl.addQuiz(question, answer);
//			System.out.println(addQuiz);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		try {
			List<QuizDTO> quizDto = quizRepositoryImpl.selectQuiz();
			for (QuizDTO quizDTO2 : quizDto) {
				System.out.println(quizDTO2);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		try {
			QuizDTO quizDTO = quizRepositoryImpl.randomQuiz();
			System.out.println("문제: " + quizDTO.getQuestion());
			System.out.println("정답: " + quizDTO.getAnswer());
		} catch (Exception e) {
			// TODO: handle exception
		}

	}
}
