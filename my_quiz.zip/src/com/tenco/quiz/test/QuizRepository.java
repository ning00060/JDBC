package com.tenco.quiz.test;

import java.util.List;

public interface QuizRepository {

	int  addQuiz(String question,String answer) ;
	List<QuizDTO> selectQuiz();
	QuizDTO randomQuiz();
	
}
