package com.tenco.quiz.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class QuizRepositoryImpl implements QuizRepository {

	private static final String ADD_QUIZ = " insert into quiz(question,answer) values (?,?) ";
	private static final String SELECT_QUIZ = " select * from quiz  ";
	private static final String RANDOM_QUIZ = " select * from quiz order by rand() limit 1 ";

	@Override
	public int addQuiz(String question, String answer) {
		int rowCount = 0;
		try (Connection conn = DBConnectionManager.getConnection()) {

			PreparedStatement pstmt = conn.prepareStatement(ADD_QUIZ);
			pstmt.setString(1, question);
			pstmt.setString(2, answer);
			rowCount = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowCount;
	}

	@Override
	public List<QuizDTO> selectQuiz() {

		List<QuizDTO> list = new ArrayList<>();
		try (Connection conn = DBConnectionManager.getConnection()) {

			PreparedStatement pstmt = conn.prepareStatement(SELECT_QUIZ);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				String question = rs.getString("question");
				String answer = rs.getString("answer");
				list.add(new QuizDTO(id, question, answer));
			}
		} catch (Exception e) {
		}
		return list;
	}

	@Override
	public QuizDTO randomQuiz() {
		QuizDTO quizDTO = null;
		try (Connection conn = DBConnectionManager.getConnection()) {

			PreparedStatement pstmt = conn.prepareStatement(RANDOM_QUIZ);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int id = rs.getInt("id");
				String question = rs.getString("question");
				String answer = rs.getString("answer");

				quizDTO = new QuizDTO(id, question, answer);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return quizDTO;
	}

}
