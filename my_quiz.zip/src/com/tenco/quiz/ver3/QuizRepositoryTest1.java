package com.tenco.quiz.ver3;

public class QuizRepositoryTest1 {

	public static void main(String[] args) {
		
		// 매서드 호출해서 실행 확인 디버깅  확인 테스트
		// QuizRepository 구현 클래스 테스트
		
		// 주말과제
		// 실행에 흐름 여러분 직접 만들기
	}

}
