package com.tenco.quiz.ver1;

public class Define {

	public static final String UPDATE_QUIZ=" UPDATE quiz Set = ... ";
}
