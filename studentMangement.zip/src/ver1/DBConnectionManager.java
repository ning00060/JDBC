package ver1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class DBConnectionManager {
	private static final Logger LOGGER = Logger.getLogger(DBConnectionManager.class.getName());
	SelectExample selectExample = new SelectExample();
	private static HikariDataSource dataSource;

	private static final String URL = "jdbc:mysql://localhost:3306/studentdb?serverTimezone=Asia/Seoul";
	private static final String USER = "root";
	private static final String PASSWORD = "asd123";

	static {
		// HikariCP 를 사용하기 위한 설정이 필요 하다.
		// HikariConfig --> 제공해줘서 이 클래스를 활용해서 설정을 상세히 할 수있다.
		HikariConfig config = new HikariConfig();
		config.setJdbcUrl(URL);
		config.setUsername(USER);
		config.setPassword(PASSWORD);

		config.setMaximumPoolSize(10);// 최대 연결 수 설정10

		dataSource = new HikariDataSource(config);
	}

	public static Connection getcConnection() throws SQLException {
		System.out.println("HikariCP 를 사용한 Data Sourece 활용");
		return dataSource.getConnection();
	}

	public static void main(String[] args) {

		try {
			Connection conn = DBConnectionManager.getcConnection();
			Scanner scanner = new Scanner(System.in);

			while (true) {
				printMenu();

				int choice = scanner.nextInt();
				if (choice == 1) {
					SelectExample.selectUser(conn);
				} else if (choice == 2) {
					System.out.print("username을 입력하세요:");
					String username = scanner.nextLine();
					System.out.println("나이를 입력하세요");
					int age = scanner.nextInt();
					System.out.print("email를 입력하세요:");
					String email = scanner.nextLine();
					InsertExample.insertUser(conn, username, age, email);
				} else if (choice == 3) {
					System.out.println("삭제할 종류을 선택해주세요:1:name 2:age 3:email");
					int num = scanner.nextInt();
					if (num == 1) {
						System.out.print("삭제할이름을 입력하세요:");
						String name = scanner.nextLine();
						DeleteExample.deletetUser(conn, name);
					} else if (num == 2) {

						System.out.println("삭제할 나이를 입력하세요");
						int age = scanner.nextInt();
						DeleteExample.deletetUser(conn, age);
					} else {
						System.out.print("email를 입력하세요:");
						String email = scanner.nextLine();
						System.out.println("다시입력해주세요");
						String email2 = scanner.nextLine();
						DeleteExample.deletetUser(conn, email, email2);
					}
				} else if (choice == 4) {
					System.out.println("변경할 종류을 선택해주세요:1:name 2:age 3:email");
					int num = scanner.nextInt();
					if (num == 1) {
						System.out.print("이름을 입력하세요:");
						String name = scanner.nextLine();
						System.out.print("변경할이름을 입력하세요:");
						String name2 = scanner.nextLine();
						UpdateExample.UpdateUser(conn, num, name, name2);
					} else if (num == 2) {

						System.out.println("나이를 입력하세요");
						int age = scanner.nextInt();
						System.out.println("변경할 나이를 입력하세요");
						int age2 = scanner.nextInt();
						UpdateExample.UpdateUser(conn, age, age2);
					} else {
						System.out.print("email를 입력하세요:");
						String email = scanner.nextLine();
						System.out.println("변경할email입력해주세요");
						String email2 = scanner.nextLine();
						UpdateExample.UpdateUser(conn, num, email, email2);
					}
				} else if (choice == 5) {
					System.out.println("프로그램을 종료합니다");
					break;
				} else {
					System.out.println("잘못된 선택입니다 . 다시 시도하세요");
				}
			}
		} catch (

		SQLException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void printMenu() {
		System.out.println();
		System.out.println("----------------------------");
		System.out.println("1. 전체 조회");
		System.out.println("2. 추가");
		System.out.println("3. 삭제");
		System.out.println("4. 수정");
		System.out.println("5. 종료");
		System.out.print("옵션을 선택하세요:");
	}

	public static int insertUser(Connection conn, String username, int age, String email) {

		int result = 0;
		String query = " insert into students(name,age,email) values(?,?,?) ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(query);
			int rowCount = pstmt.executeUpdate();
			pstmt.setString(1, "name");
			pstmt.setString(2, "age");
			pstmt.setString(3, "email");
			System.out.println("rowCount:" + rowCount);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
}
