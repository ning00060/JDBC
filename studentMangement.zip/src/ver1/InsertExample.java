package ver1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class InsertExample {
	private static final Logger LOGGER = Logger.getLogger(InsertExample.class.getName());

	public static void main(String[] args) {
		// DataSource를 활용한 Connection 객체를 사용하자

		try {
			// Hikaricp가 담김
			Connection conn = DBConnectionManager.getcConnection();

			Scanner scanner = new Scanner(System.in);
			System.out.print("username을 입력하세요:");
			String username = scanner.nextLine();
			System.out.println("나이를 입력하세요");
			int age = scanner.nextInt();
			System.out.print("email를 입력하세요:");
			String email = scanner.nextLine();

		} catch (SQLException e) {
			LOGGER.log(Level.INFO, "mySQL 연결 오류");
			e.printStackTrace();
		}

	}

	public static int insertUser(Connection conn, String username, int age, String email) {
		int result = 0;
		String query = " insert into students(name,age,email) values(?,?,?) ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(query);
			int rowCount = pstmt.executeUpdate();
			pstmt.setString(1, username);
			pstmt.setInt(2, age);
			pstmt.setString(3, email);
			System.out.println("rowCount:" + rowCount);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
}
