package ver1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SelectExample {
	private static final Logger LOGGER = Logger.getLogger(SelectExample.class.getName());

	public static void main(String[] args) {
		// DataSource를 활용한 Connection 객체를 사용하자

		try {
			// Hikaricp가 담김
			Connection conn = DBConnectionManager.getcConnection();

		} catch (SQLException e) {
			LOGGER.log(Level.INFO, "mySQL 연결 오류");
			e.printStackTrace();
		}

	}

	public static void selectUser(Connection conn) {
		String query = " select * from students ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println(" ID : " + rs.getInt("id"));
				System.out.println("이름 : " + rs.getString("name"));
				System.out.println("나이 : " + rs.getInt("age"));
				System.out.println("이메일 : " + rs.getString("email"));
				if (!rs.isLast()) {
					System.out.println("----------------------");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
