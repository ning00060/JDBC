package ver1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateExample {
	private static final Logger LOGGER = Logger.getLogger(UpdateExample.class.getName());

	public static void main(String[] args) {
		// DataSource를 활용한 Connection 객체를 사용하자

		try {
			// Hikaricp가 담김
			Connection conn = DBConnectionManager.getcConnection();

			Scanner scanner = new Scanner(System.in);
			System.out.println("변경할 종류을 선택해주세요:1:name 2:age 3:email");
			int num = scanner.nextInt();
			if (num == 1) {
				System.out.print("이름을 입력하세요:");
				String name = scanner.nextLine();
				System.out.print("변경할이름을 입력하세요:");
				String name2 = scanner.nextLine();

			} else if (num == 2) {

				System.out.println("나이를 입력하세요");
				int age = scanner.nextInt();
				System.out.println("변경할 나이를 입력하세요");
				int age2 = scanner.nextInt();
			} else {
				System.out.print("email를 입력하세요:");
				String email = scanner.nextLine();
				System.out.println("변경할email입력해주세요");
				String email2 = scanner.nextLine();
			}

		} catch (SQLException e) {
			LOGGER.log(Level.INFO, "mySQL 연결 오류");
			e.printStackTrace();
		}

	}

	public static int UpdateUser(Connection conn, int num, String name, String name2) {
		int result = 0;

		try {
			String query = " update students set ?=? where ? =? ";
			PreparedStatement pstmt = conn.prepareStatement(query);
			int rowCount = pstmt.executeUpdate();
			if (num == 1) {
				pstmt.setString(1, "name");
				pstmt.setString(3, "name");
				pstmt.setString(2, name);
				pstmt.setString(4, name2);

			} else if (num == 3) {
				pstmt.setString(1, "email");
				pstmt.setString(3, "email");
				pstmt.setString(2, name);
				pstmt.setString(4, name2);
			}
			System.out.println("rowCount:" + rowCount);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

	public static int UpdateUser(Connection conn, int age, int age2) {
		int result = 0;
		String query = " update students set age=? where age =?  ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(query);
			int rowCount = pstmt.executeUpdate();
			pstmt.setInt(1, age);
			pstmt.setInt(1, age2);
			System.out.println("rowCount:" + rowCount);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

}
