package ver1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteExample {
	private static final Logger LOGGER = Logger.getLogger(DeleteExample.class.getName());

	public static void main(String[] args) {
		// DataSource를 활용한 Connection 객체를 사용하자

		try {
			// Hikaricp가 담김
			Connection conn = DBConnectionManager.getcConnection();

			Scanner scanner = new Scanner(System.in);
			System.out.println("삭제할 종류을 선택해주세요:1:name 2:age 3:email");
			int num = scanner.nextInt();
			if (num == 1) {
				System.out.print("삭제할이름을 입력하세요:");
				String name = scanner.nextLine();

			} else if (num == 2) {

				System.out.println("삭제할 나이를 입력하세요");
				int age = scanner.nextInt();
			} else {
				System.out.print("email를 입력하세요:");
				String email = scanner.nextLine();
				System.out.println("다시입력해주세요");
				String email2 = scanner.nextLine();
			}

		} catch (SQLException e) {
			LOGGER.log(Level.INFO, "mySQL 연결 오류");
			e.printStackTrace();
		}

	}

	public static int deletetUser(Connection conn, String name) {
		int result = 0;
		String query = " DELETE FROM students WHERE username=? ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(query);
			int rowCount = pstmt.executeUpdate();
			pstmt.setString(1, name);
			System.out.println("rowCount:" + rowCount);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static int deletetUser(Connection conn, int age) {
		int result = 0;
		String query = " DELETE FROM students WHERE age=? ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(query);
			int rowCount = pstmt.executeUpdate();
			pstmt.setInt(1, age);
			System.out.println("rowCount:" + rowCount);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static int deletetUser(Connection conn, String email, String email2) {
		if (email == email2) {

			System.out.println(email2 + "를입력하셨습니다");
			int result = 0;
			String query = " DELETE FROM students WHERE email=? ";

			try {
				PreparedStatement pstmt = conn.prepareStatement(query);
				int rowCount = pstmt.executeUpdate();
				pstmt.setString(1, email);
				System.out.println("rowCount:" + rowCount);

			} catch (SQLException e) {
				e.printStackTrace();
			}
			return result;
		} else {
			System.out.println("잘못입력하셨습니다");
			int result = 0;
			return result;
		}

	}

}
