package ver2;

import java.sql.SQLException;
import java.util.List;

import ver2.model.StudentDTO;

public class StudentManagermentSystem {

	private static final StudentDAO studentDAO = new StudentDAO();

	public static void main(String[] args) {
		try {
			List<StudentDTO> list = studentDAO.getALLStudents();
			System.out.println(list.size());
			System.out.println(list.toString());
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
